﻿<#PSScriptInfo
    .VERSION 1.0.0.0
    .GUID 6746c383-3590-4a42-b8e0-1a4134e6f216
    .FILENAME Set-DaikinAirCon.ps1
    .AUTHOR Hannes Palmquist
    .AUTHOREMAIL hannes.palmquist@outlook.com
    .CREATEDDATE 2020-10-03
    .COMPANYNAME Personal
    .COPYRIGHT (c) 2020, , All Rights Reserved
#>
function Set-DaikinAirCon
{
    <#
    .DESCRIPTION
        Cmdlet allows to configure the aircon device to the desired setting.
    .PARAMETER Hostname
        Hostname or IP of the Daikin AirCon device.
    .PARAMETER PowerOn
        Set to $true or $false to specify if the master power should be on or off. This does not the affect the connectivity of the control surfice.
    .PARAMETER Temp
        Specified the target temperature in celcius.
    .PARAMETER Mode
        Specifies the operating mode of the aircon device. Allowed values are;
        AUTO  : Switches between heat and cold depending on the current and target temperature.
        DRY   : Sets the device lower the humidity of the air.
        COLD  : Sets the device chill the air if needed. No heat will be provided.
        HEAT  : Sets the device heat the air if needed. No chilling of air will be provided.
        FAN   : Sets the device to only circulate air without affecting temperature or humidity.
    .PARAMETER FanSpeed
        Specifies the strenght of the fan. Allowed values are;
        AUTO   : Sets the device to manage fan speed to keep the target climate.
        SILENT : Sets the fan speed to minimize noise.
        Level_1 -> Level_5 : Sets the fan speed to the target level.
    .PARAMETER FanDirection
        Specifies how the direction of airflow is controlled. Allowed values are
        Stopped, VerticalSwing, HorizontalSwing and BothSwing 
    .EXAMPLE
        Set-DaikinAirCon -HostName daikin.local.network -PowerOn:$true -Temp 19 -Mode AUTO -FanSpeed AUTO -FanDirection Stopped
        
        This example configures the aircon device to the specified parameter values.
    #>

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidInvokingEmptyMembers', '', Justification = 'asd')]
    [CmdletBinding()] # Enabled advanced function support
    param(
        $HostName,
        [boolean]$PowerOn,
        [ValidateRange(10, 41)][int]$Temp,
        [ValidateSet('AUTO', 'DRY', 'COLD', 'HEAT', 'FAN')]$Mode,
        [ValidateSet('AUTO', 'SILENT', 'Level_1', 'Level_2', 'Level_3', 'Level_4', 'Level_5')]$FanSpeed,
        [ValidateSet('Stopped', 'VerticalSwing', 'HorizontalSwing', 'BothSwing')]$FanDirection
    )

    BEGIN
    {
        $ModeTranslation = @{
            'AUTO' = '1'
            'DRY'  = '2'
            'COLD' = '3'
            'HEAT' = '4'
            'FAN'  = '6'
        }
        $FanSpeedTranslation = @{
            'AUTO'    = 'A'
            'SILENT'  = 'B'
            'Level_1' = 'lvl_1'
            'Level_2' = 'lvl_2'
            'Level_3' = 'lvl_3'
            'Level_4' = 'lvl_4'
            'Level_5' = 'lvl_5'

        } 
        $FanDirectionTranslation = @{
            'Stopped'         = '0'
            'VerticalSwing'   = '1'
            'HorizontalSwing' = '2'
            'BothSwing'       = '3'
        }

        $CurrentSettings = Get-DaikinControlInfo -Hostname:$Hostname -Raw
        $NewSettings = [ordered]@{
            'pow'    = $CurrentSettings.pow
            'mode'   = $CurrentSettings.mode
            'stemp'  = $CurrentSettings.stemp
            'shum'   = $CurrentSettings.shum
            'f_rate' = $CurrentSettings.f_rate
            'f_dir'  = $CurrentSettings.f_dir
        }
    }

    PROCESS
    {
        foreach ($Key in $PSBoundParameters.Keys)
        {
            if ($Key -eq 'HostName') { continue }
            switch ($Key)
            {
                'Temp' { $NewSettings.stemp = $PSBoundParameters.$Key }
                'PowerOn' { $NewSettings.pow = $PSBoundParameters.$Key }
                'Mode' { $NewSettings.mode = $ModeTranslation.($PSBoundParameters.$Key) }
                'FanSpeed' { $NewSetting.f_rate = $FanSpeedTranslation.($PSBoundParameters.$Key) }
                'FanDirection' { $NewSetting.f_dir = $FanDirectionTranslation.($PSBoundParameters.$Key) }
            }
        }
        if ($NewSettings.stemp -eq '--')
        {
            $NewSettings.stemp = $CurrentSettings.('dt{0}' -f $NewSettings.Mode)
        }
        if ($NewSettings.shum -eq '--')
        {
            $NewSettings.shum = $CurrentSettings.('dh{0}' -f $NewSettings.Mode)
        }
    }

    END
    {
        $String = @()
        foreach ($Key in $NewSettings.Keys)
        {
            $String += ('{0}={1}' -f $Key, $NewSettings.$Key)
        } 
        $PropertyString = $String -join '&'
    
        $URI = ('http://{0}/aircon/set_control_info?{1}' -f $HostName, $PropertyString)
        $Result = Invoke-RestMethod -Uri $uri -Method post
        $Result = Convert-DaikinResponse -String $Result

        switch ($Result.ret)
        {
            'OK' { Write-Success -Message 'Successfully sent command to AirCon' -Target $Hostname }
            'PARAM NG' { Write-Error -Message ('Command failed: [PARAM NG]') -TargetObject $Hostname }
            default { Write-Warning -Message ('Unknown message returned: {0}' -f $PSItem) -Target $HostName }
        } 
    }

}
#endregion



# SIG # Begin signature block
# MIIR2AYJKoZIhvcNAQcCoIIRyTCCEcUCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU5OyiugMJ7W9zWAykYvGvSj/X
# M3Gggg0/MIIDBDCCAeygAwIBAgIQXaH43Bl75ZhMB4kpXyZ2qjANBgkqhkiG9w0B
# AQUFADAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwHhcNMjAxMDIyMDczMDU3
# WhcNMjUxMDIyMDc0MDU3WjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClDvznsRz3hBOHS8rZ5ZlNB/ac
# GrKUQyoH0Pk6JONmIBeQPLwurne3ulSwb+6cbwwgp87eSnGoq4YbAFfqTbwytKLn
# YmIoHGiCrwxZb5YU6ijOrW6Sywa+H+/uKsZqJfXFRn1vGnC5tZwa5rSngLaow1qV
# tvyRQGRGNpI02hUwtChneJJmwk2B8dtY1ECH6Ob9LFlWETcETy5T5RKSS1sRWATk
# K9EQsZ65AHbGKGkpDv8y/+g7hg3KKU+m8f3ahMscMB5tvyPr3tmPsMFpFW3kCfz0
# FRBOizw+HYZX6nnSQ+aTMyXNuIXCv4Cp+1rSGdLwnRqbY5iUQca/8VZF45iZAgMB
# AAGjRjBEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNV
# HQ4EFgQU1v0fOEkDehQn807IU73u51uJNQ0wDQYJKoZIhvcNAQEFBQADggEBABwb
# e2Ghq71GqGwx2/GoXa/Nv4XhW2O0TT5vgn6RysorCPUKTnCYKn6wGWZpdMbndXXU
# d6ziS+EW0+cxr7ZdFCTsfBroArJ3BIFjPoRt3hYqZR154nLNRnFPKhzgpusqDpSx
# BnMd7wRrKsW3GdSOfeGyiR7/9Ye2uiFp6y4wpU/qcU+LuxS2fbyUB2XGVPPWXxxF
# bjtgrlit7czi7WTjfe4YVgxyyrJ9IsMz8fPlLPy9Pfbfacpo6/p6qINhsmv+/V1o
# 7U2XIlg2w1ABj20sZ3mn+TKS2mmxNkIdCb38rUK8UJwqHX9byi9M1MrJYFJwRNwH
# 37l4hxzeVXIaiA6vWJAwggT+MIID5qADAgECAhANQkrgvjqI/2BAIc4UAPDdMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwHhcNMjEwMTAxMDAwMDAw
# WhcNMzEwMTA2MDAwMDAwWjBIMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFtcCAyMDIxMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwuZhhGfFivUNCKRFymNrUdc6EUK9
# CnV1TZS0DFC1JhD+HchvkWsMlucaXEjvROW/m2HNFZFiWrj/ZwucY/02aoH6Kfjd
# K3CF3gIY83htvH35x20JPb5qdofpir34hF0edsnkxnZ2OlPR0dNaNo/Go+EvGzq3
# YdZz7E5tM4p8XUUtS7FQ5kE6N1aG3JMjjfdQJehk5t3Tjy9XtYcg6w6OLNUj2vRN
# eEbjA4MxKUpcDDGKSoyIxfcwWvkUrxVfbENJCf0mI1P2jWPoGqtbsR0wwptpgrTb
# /FZUvB+hh6u+elsKIC9LCcmVp42y+tZji06lchzun3oBc/gZ1v4NSYS9AQIDAQAB
# o4IBuDCCAbQwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/
# BAwwCgYIKwYBBQUHAwgwQQYDVR0gBDowODA2BglghkgBhv1sBwEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMB8GA1UdIwQYMBaAFPS2
# 4SAd/imu0uRhpbKiJbLIFzVuMB0GA1UdDgQWBBQ2RIaOpLqwZr68KC0dRDbd42p6
# vDBxBgNVHR8EajBoMDKgMKAuhixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hh
# Mi1hc3N1cmVkLXRzLmNybDAyoDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29t
# L3NoYTItYXNzdXJlZC10cy5jcmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcw
# AYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8v
# Y2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0
# YW1waW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQBIHNy16ZojvOca5yAOjmdG
# /UJyUXQKI0ejq5LSJcRwWb4UoOUngaVNFBUZB3nw0QTDhtk7vf5EAmZN7WmkD/a4
# cM9i6PVRSnh5Nnont/PnUp+Tp+1DnnvntN1BIon7h6JGA0789P63ZHdjXyNSaYOC
# +hpT7ZDMjaEXcw3082U5cEvznNZ6e9oMvD0y0BvL9WH8dQgAdryBDvjA4VzPxBFy
# 5xtkSdgimnUVQvUtMjiB2vRgorq0Uvtc4GEkJU+y38kpqHNDUdq9Y9YfW5v3LhtP
# Ex33Sg1xfpe39D+E68Hjo0mh+s6nv1bPull2YYlffqe0jmd4+TaY4cso2luHpoov
# MIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfCFTANBgkqhkiG9w0BAQsFADBl
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJv
# b3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3MTIwMDAwWjByMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0
# YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvdAy7kvN
# j3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7ntqD0jbOI5Je/YyGQmL8TvFfT
# w+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcGGlV+Cyd+wKL1oODeIj8O/36V
# +/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr4M8iEA91z3FyTgqt30A6XLdR
# 4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZuVmEnKYmEUeaC50ZQ/ZQqLKfk
# dT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N1k3vBkL9olMqT4UdxB08r8/a
# rBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0OBBYEFPS24SAd/imu0uRhpbKi
# JbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGBBgNVHR8EejB4MDqgOKA2hjRo
# dHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0Eu
# Y3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1
# cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYKYIZIAYb9bAACBDAqMCgGCCsG
# AQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwH
# ATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN793afKpjerN4zwY3QITvS4S/
# ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgnoma/Capg33akOpMP+LLR2HwZ
# YuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jWPGTlH0gQGF+JOGFNYkYkh2OM
# kVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tTYYmo9WuWwPRYaQ18yAGxuSh1
# t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhgm7oMLSttosR+u8QlK0cCCHxJ
# rhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skuiSpXY9aaOUjGCBAMwggP/AgEB
# MC4wGjEYMBYGA1UEAwwPSGFubmVzUGFsbXF1aXN0AhBdofjcGXvlmEwHiSlfJnaq
# MAkGBSsOAwIaBQCgeDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MCMGCSqGSIb3DQEJBDEWBBSb+bGqBeXE/OlnKk4AYj5+9Hm+OzANBgkqhkiG9w0B
# AQEFAASCAQB6EZckXX5cGWRqYDeIvuMwIGPug714RZ+CqUTmhKHyCAlQbq5ldk9Y
# Q1ZKSqUlwSYry/w34QaGgZXcOigZMm1MCUap5b1YpYJPSx9VfTiqePlCRxNIhxr9
# kFIuKJ6sgNDiwOJbo3bk6xIkhA8Df3PBsUT4QWw8ilpk53QVFHzP74FvLmM4ipIu
# iFPSk+rJs03vYU43VdhV+69olTcfVwk5SKBYigfGigmsIQssLXVnH2VrIt6cFl9u
# Haw9/6wXZUbZn6qL6OM+CNOr4Jn4oklu50egfoHZO0mgolsL6P4YjXnzmQ6VGVdu
# Ou1lhY/pd/UkId/cbnAd5ZFW5OfrSAcWoYICMDCCAiwGCSqGSIb3DQEJBjGCAh0w
# ggIZAgEBMIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNI
# QTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0ECEA1CSuC+Ooj/YEAhzhQA8N0w
# DQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
# SIb3DQEJBTEPFw0yMTAzMjIyMzI2MzBaMC8GCSqGSIb3DQEJBDEiBCALybsVIFQI
# ohCoL3NXYqx+Vv/4IJu1YliaK8mCuclSgjANBgkqhkiG9w0BAQEFAASCAQBBbInJ
# vlnPosPn/zVj91/EoWcUfhdUfiwCbz11xX27eO5jZIKWVGMEDmwQzNjdzgf9W9De
# HTVFX4+fZJE3AH/0yumaPJOxDq9OqE+tMCKMXlZElBfRb19eWX+oedIiSEmgwsoU
# hteg7mVo9FM9MmAP6JSPwpyslZx2sUP9GzqaJvHKwaqspluAKJcWpWEtM6Ty+3p1
# RmHck1nihgT7PN8Ba+2b6k0UfcTzcyH4vb0tI51Ilj/7Hq4kLgjkD2EaC+bhWXJu
# uF+hIdm+RV24IA7neIN9JxKs+x4ZyP3kKEVBwAmvdtLZjv47qHkrpB3eQrADdmxy
# uHvbKDH/uc2r7sim
# SIG # End signature block
